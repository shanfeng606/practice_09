<template>
  <div class="category">
    category
  </div>
</template>

<script>

  export default {
    name: 'category'
  };
</script>
<style lang="scss" scoped>

</style>
